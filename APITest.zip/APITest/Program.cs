﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Configuration;



namespace APITest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                WebClient webClient = new WebClient();
                string getCountResult = webClient.DownloadString(ConfigurationManager.AppSettings["url"]);

                dynamic item = JsonConvert.DeserializeObject<object>(getCountResult);
                List<StateDet> items = ((JArray)item["RestResponse"]["result"]).Select(x => new StateDet
                {
                    id = (int)x["id"],
                    country = (string)x["country"],
                    name = (string)x["name"],
                    abbr = (string)x["abbr"],
                    area = (string)x["area"],
                    largest_city = (string)x["largest_city"],
                    capital = (string)x["capital"]

                }).ToList();

                StringBuilder sb = new StringBuilder();
                int count = 0;
                do
                {
                    sb.Clear();
                    sb.Append(enterValue());
                    count = 0;
                    foreach (StateDet obj in items)
                    {
                        if (obj.name.ToLower() == sb.ToString().ToLower()|| obj.abbr.ToLower() == sb.ToString().ToLower())
                        {
                            System.Console.WriteLine("Largest City : " + obj.largest_city);
                            System.Console.WriteLine("Capital : " + obj.capital);
                            count++;
                            break;
                        }
                    }
                    if (count == 0)
                    {
                        System.Console.WriteLine("State Name or Appbivation does not match");
                    }

                    sb.Clear();
                    sb.Append(toContinue());                    

                } while (sb.ToString().ToLower() == "y");

            }
            catch (Exception ex)
            {
                System.Console.WriteLine("Exception occured : " + ex.Message);
                System.Console.ReadLine();
            }
        }

        private static String enterValue()
        {
            string str = string.Empty;
            do
            {
                try
                {
                    System.Console.WriteLine("Enter the State Name or Appbivation");
                    str = System.Console.ReadLine().Trim();                    
                }
                catch (Exception exp)
                {
                    System.Console.WriteLine("Exception : " + exp.Message);
                    System.Console.ReadLine();                    
                }               

            } while (str.Trim().Length == 0);

            return str;
        }

        private static String toContinue()
        {
            string str = string.Empty;
            do
            {
                try
                {
                    System.Console.WriteLine("Do you want continue");
                    str = System.Console.ReadLine().Trim();
                    if (str.Trim().ToLower() != "y" && str.Trim().ToLower() != "n")
                    {
                        System.Console.WriteLine("Enter 'Y' to continue or 'N' to exit");
                        str = string.Empty;
                    }
                }
                catch (Exception exp)
                {
                    System.Console.WriteLine("Exception : " + exp.Message);
                    System.Console.ReadLine();
                }

            } while (str.Trim().Length == 0);

            return str;
        }

        public class StateDet
        {
            public int id { set; get; }
            public string country { set; get; }
            public string name { set; get; }
            public string abbr { set; get; }
            public string area { set; get; }
            public string largest_city { set; get; }
            public string capital { set; get; }
        }


        
    }

   
}
