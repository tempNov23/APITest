﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        public static List<StateDet> stateList = null;
        public class StateDet
        {
            public int id { set; get; }
            public string country { set; get; }
            public string name { set; get; }
            public string abbr { set; get; }
            public string area { set; get; }
            public string largest_city { set; get; }
            public string capital { set; get; }
        }

        [ClassInitialize()]
        public static void ClassInit(TestContext context)
        {

            WebClient webClient = new WebClient();
            string getCountResult = webClient.DownloadString("http://services.groupkt.com/state/get/USA/all");

            dynamic item = JsonConvert.DeserializeObject<object>(getCountResult);
            List<StateDet> items = ((JArray)item["RestResponse"]["result"]).Select(x => new StateDet
            {
                id = (int)x["id"],
                country = (string)x["country"],
                name = (string)x["name"],
                abbr = (string)x["abbr"],
                area = (string)x["area"],
                largest_city = (string)x["largest_city"],
                capital = (string)x["capital"]

            }).ToList();

            stateList = items;
        }

        [TestMethod()]
        public void TestMethod1()
        {
            string statename = "Mississippi";
            string abbabbreviation = "";

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }
        [TestMethod()]
        public void TestMethod2()
        {
            string statename = "";
            string abbabbreviation = "MS";

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }

        [TestMethod()]
        public void TestMethod3()
        {
            string statename = "Mississippi";
            string abbabbreviation = "MS";

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }

        [TestMethod()]
        public void TestMethod4()
        {
            string statename = "";
            string abbabbreviation = "";

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }

        [TestMethod()]
        public void TestMethod5()
        {
            string statename = "@@@@@";
            string abbabbreviation = "%^&***";

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }

        [TestMethod()]
        public void TestMethod6()
        {
            string statename = null;
            string abbabbreviation = null;

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }

        [TestMethod()]
        public void TestMethod7()
        {
            string statename = "123";
            string abbabbreviation = "678";

            List<StateDet> list = stateList.Where(x => x.name == statename || x.abbr == abbabbreviation).ToList();
            Assert.AreEqual(1, list.Count);

        }
    }
}
