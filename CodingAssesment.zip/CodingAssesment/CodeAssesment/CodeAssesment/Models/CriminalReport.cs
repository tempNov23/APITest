﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CodeAssesment.BaseClasses;

namespace CodeAssesment.Models
{
    public class CriminalReport : Order
    {
         public override void AddService()
        {
            serviceList.Add(1);
        }

        public override string CancelOrder()
        {
            return " CriminalReport Order cancelled";
        }

        public override string SendToBilling()
        {
            return " CriminalReport Send to Billing";
        }
    }
}