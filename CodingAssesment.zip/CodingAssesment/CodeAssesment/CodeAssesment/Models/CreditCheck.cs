﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CodeAssesment.BaseClasses;

namespace CodeAssesment.Models
{
    public class CreditCheck : Order
    {
         public override void AddService()
        {
            serviceList.Add(1);
        }

         public override string CancelOrder()
        {
            return " CreditChecks Order cancelled";
        }

        public override string SendToBilling()
        {
            return " CreditChecks Send to Billing";
        }
    }
}