﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CodeAssesment.BaseClasses;

namespace CodeAssesment.Models
{
    public class Paramed : Order
    {
        public override void AddService()
        {
            serviceList.Add(1);
        }

       
        public override string CancelOrder()
        {
            return "Paramed Order cancelled";
        }

        public override string SendToBilling()
        {
            return "Paramed Send to Billing";
        }
    }
}