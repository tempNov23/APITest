﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CodeAssesment.ViewModel;
using CodeAssesment.Models;
using CodeAssesment.BaseClasses;
using CodeAssesment.Utility;
using CodeAssesment.Interfaces;

namespace CodeAssesment.Controllers
{
    public class OrderController : Controller
    {
        private object severity;


        // GET: Order
        public ActionResult Index()
        {
            
            var model = new OrderService()
            {
                OrderID = "0",
                CustomerName = "",
                AccountNumber = ""               
            };            

            return View(model);
        }

        private void  AddServiceToList(Order order)
        {
            bool exists = false;

            foreach (Order obj in utility.getUtility().GetOrders())
            {
                if(obj.OrderID == order.OrderID && obj.CustomerName == order.CustomerName && obj.AccountNumber == order.AccountNumber)
                {
                    obj.AddService();
                    exists = true;
                    break;
                }
            }
            if(!exists)
            {
                order.AddService();
                utility.getUtility().AddOrder(order);
            }
        }

        public ActionResult AddService(OrderService service)
        {
            int id =  Convert.ToInt32(service.OrderTypeId);
            switch(id)
            {
                case 1:
                    { Paramed obj = new Paramed();
                        obj.OrderID = Convert.ToInt32(service.OrderID);
                        obj.AccountNumber = service.AccountNumber;
                        obj.CustomerName = service.CustomerName;
                        AddServiceToList(obj);
                    }
                    break;
                case 2:
                    {
                        CreditCheck obj = new CreditCheck();
                        obj.OrderID = Convert.ToInt32(service.OrderID);
                        obj.AccountNumber = service.AccountNumber;
                        obj.CustomerName = service.CustomerName;
                        AddServiceToList(obj);
                    }
                    break;
                case 3:
                    {
                        Paramed obj = new Paramed();
                        obj.OrderID = Convert.ToInt32(service.OrderID);
                        obj.AccountNumber = service.AccountNumber;
                        obj.CustomerName = service.CustomerName;
                        AddServiceToList(obj);
                    }
                    break;
            }

            return Json("Service Added", JsonRequestBehavior.AllowGet);
        }

        public ActionResult RetrieveOrders()
        {
            return Json(utility.getUtility().GetOrders(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult CancelOrder(OrderService service)
        {
            string result = string.Empty;
            foreach (Order obj in utility.getUtility().GetOrders())
            {
                if (obj.OrderID == Convert.ToInt32(service.OrderID))
                {
                    utility.getUtility().RemoveOrder(obj);
                    result = obj.CancelOrder();
                    break;
                }
            }
            if (result.Length == 0)
                result = "Could not find the order";
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        
         public ActionResult SendBilling(OrderService service)
        {
            string result = string.Empty;
            try {
                foreach (Order obj in utility.getUtility().GetOrders())
                {
                    if (obj.OrderID == Convert.ToInt32(service.OrderID))
                    {
                        result = obj.SendToBilling();
                        break;
                    }
                }           
                
            if (result.Length == 0)
                result = "Could not find the order";
            }
            catch (Exception ex)
            {
                TextLog log = new TextLog();
                log.AddLogMessage(ex.Message, Severity.High);
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}