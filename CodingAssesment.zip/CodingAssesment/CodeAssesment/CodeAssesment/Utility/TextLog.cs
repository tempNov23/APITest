﻿using CodeAssesment.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeAssesment.Utility
{
    public class TextLog : IConfig
    {
        public void AddLogMessage(string message, Severity severity)
        {
            // writing in to Text File.
        }
    }
}