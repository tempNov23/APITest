﻿using CodeAssesment.BaseClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeAssesment.Utility
{
    public class utility
    {
        private static utility _utility = null;
        private  List<Order> orders = new List<Order>();

        private utility()
        { }

        public static utility getUtility()
        {
            if(_utility == null)
            {
                _utility = new utility();
            }

            return _utility;
        }

        public List<Order> GetOrders()
        {
            return orders;
        }

        public void AddOrder(Order order)
        {
            orders.Add(order);
        }

        public void RemoveOrder(Order order)
        {
            orders.Remove(order);
        }
    }
}