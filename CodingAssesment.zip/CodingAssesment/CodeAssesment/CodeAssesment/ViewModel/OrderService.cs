﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CodeAssesment.ViewModel
{
    public class OrderService
    {
        public string OrderID { set; get; }
        public string CustomerName { set; get; }
        public string AccountNumber { set; get; }
        
        public string OrderTypeId { set; get; }        
    }
}