﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeAssesment.BaseClasses
{
    public abstract class Order
    {
        //order id, customer name, account number, and a collection of services
        private int orderId;
        private string name;
        private string accountnumber;
        public List<int> serviceList = new List<int>();

        public int OrderID
        {
            get
            {
                return orderId;
            }

            set
            {
                orderId = value;
            }
        }
        public string CustomerName
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }
        public string AccountNumber
        {
            get
            {
                return accountnumber;
            }

            set
            {
                accountnumber = value;
            }
        }
              

        public abstract void AddService();        
        public abstract string CancelOrder();
        public abstract string SendToBilling();

       
    }
}