﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeAssesment.Interfaces
{
    public enum Severity
    {
        High =1,
        Medium =2,
        Low =3
    }
    public interface IConfig
    {
        void AddLogMessage(string message, Severity severity);
    }
}
